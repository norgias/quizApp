var question97 = document.getElementsByName("question97");
var question98 = document.getElementsByName("question98");
var question99 = document.getElementsByName("question99");

var myArr = [question97,question98,question99];
var score = 0;
var firstPara = document.getElementById("firstPara");
var secondPara = document.getElementById("secondPara");

$('.button').click(function(){


	for(var i=0;i<myArr.length;i++) {
		for(var o=0;o<question97.length;o++) {
			if(myArr[i][o].value == "true"  && myArr[i][o].checked) {
                firstPara.innerHTML += "you got question " + (i+1) + " correct!";
			    score++; 
		}
	}

    }

    var showScore = Math.round((score/3)*100);
    secondPara.innerHTML += showScore;

});






